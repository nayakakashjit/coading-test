import { Component, OnInit } from "@angular/core";
import { HomeService } from "../../services/home/home.service";
import { tap, finalize, catchError } from "rxjs/operators";
import { of } from "rxjs";
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"],
})
export class HomeComponent implements OnInit {
  error: any;
  initCallData: [];
  years: any[];
  queryString = {
    limit: 100,
  };
  activeFlag: boolean;
  activeFlag1: boolean;
  activeFlag2: boolean;
  constructor(
    private homeservice: HomeService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {
    this.initCall();
    this.getYears(2006);
  }

  
  // Get Years
  getYears(startYear) {
    this.years = [];
    let currentYear = new Date().getFullYear();
    startYear = startYear || 1980;
    for (startYear; startYear <= currentYear; startYear++) {
      this.years.push(startYear);
    }
  }

  // Get Initail Call and also Common For all filter
  initCall() {
    this.spinner.show();
    this.homeservice.initiateApi(this.queryString).pipe(
        tap((response) => {
          this.initCallData = response;
        }),
        finalize(() => this.spinner.hide()),
        catchError((error) => of((this.error = error)))
      )
      .subscribe();
  }

  // Filter By Year
  yearFilter(year) {
    this.activeFlag = year;
    this.queryString["launch_year"] = year;
    this.initCall();
  }

  // Filter By Lunch
  lunchFilter(lunchVal) {
    this.activeFlag1 = lunchVal;
    this.queryString["launch_success"] = lunchVal;
    this.initCall();
  }

  // Filter By Landing
  landingFliter(landVal) {
    this.activeFlag2 = landVal;
    this.queryString["land_success"] = landVal;
    this.initCall();
  }
}
