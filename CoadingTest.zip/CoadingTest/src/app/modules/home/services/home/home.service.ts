import { Injectable } from '@angular/core';
import { ApiService } from '../../../../core/services';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private apiService: ApiService) { }

  initiateApi(queryString) {
    return this.apiService.get('/launches', queryString)
  }
}
