import { Routes } from '@angular/router';

export const moduleRoutes : Routes = [
    { path: 'home', loadChildren: 'src/app/modules/home/home.module#HomeModule'},
]