export const environment = {
  production: true,
  server_url: 'https://api.spaceXdata.com/v3'
};
